<?php

class UberMenuItemCustom extends UberMenuItemDefault{

	var $type = 'custom_content';

	function get_anchor( $atts ){ return ''; }

}